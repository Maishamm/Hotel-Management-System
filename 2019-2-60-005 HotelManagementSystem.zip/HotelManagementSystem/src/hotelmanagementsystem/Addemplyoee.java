
package hotelmanagementsystem;
        
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Addemplyoee extends JFrame implements ActionListener {

    JLabel name,age,gender,job,salary,phone;
    JTextField t1,t2,t3,t4;
    JRadioButton r1,r2;
    JButton b1;
    JComboBox c1;

    Addemplyoee(){
    
    name= new JLabel("Name");
           name.setBounds(60,30,120,30);
           name.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(name);
          
           t1 = new JTextField();
          t1.setBounds(200,30,150,30);
          add(t1);
          
           age = new JLabel("Age");
           age.setBounds(60,80,120,30);
           age.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(age);
          
           t2 = new JTextField();
          t2.setBounds(200,80,150,30);
          add(t2);
          
            gender = new JLabel("Gender");
           gender.setBounds(60,130,120,30);
           gender.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(gender);
          
           r1 = new JRadioButton("Male");
           r1.setBounds(200,130,70,30);
           r1.setFont(new Font("Tahoma",Font.PLAIN,14));
          add(r1);
          
             r2 = new JRadioButton("Female");
           r2.setBounds(280,130,70,30);
           r2.setFont(new Font("Tahoma",Font.PLAIN,14));
          add(r2);
          
           job = new JLabel("Job");
           job.setBounds(60,180,120,30);
           job.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(job);
          
          String str[] = {"Manager","Receptionist","Chef","Staff"};
          c1 = new JComboBox(str);
          c1.setBounds(200,180,150,30);
          add(c1);
          
            salary = new JLabel("Salary");
           salary.setBounds(60,230,120,30);
           salary.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(salary);
          
           t3 = new JTextField();
          t3.setBounds(200,230,150,30);
          add(t3);
      
           phone = new JLabel("Phone");
           phone.setBounds(60,280,120,30);
           phone.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(phone);
          
           t4 = new JTextField();
          t4.setBounds(200,280,150,30);
          add(t4);
          
          b1 = new JButton("Submit");
          b1.setBounds(200,330,150,30);
          b1.addActionListener(this);
          add(b1);
          
         setLayout(null);
         //setBackground(Color.BLACK);
         setBounds(400,220,550,450);
         setVisible(true);
}    

    @Override
    public void actionPerformed(ActionEvent ae) {
       String Name = t1.getText();
         String Age = t2.getText();
           String Salary = t3.getText();
             String Phone = t4.getText();
             
             String Gender = null;
             if(r1.isSelected()){
                 Gender = "Male";
              }
             else if(r2.isSelected()){
                 Gender = "Female";
             }
             
             String Job =(String)c1.getSelectedItem(); 
             conn c = new conn();
             
             String str = "insert into emplyoee values('"+Name+"','"+Age+"','"+Gender+"','"+Job+"','"+Salary+"','"+Phone+"')";
             try{
                c.s.executeUpdate(str);
               JOptionPane.showMessageDialog(null,"New employee Added");
                this.setVisible(false);
             }
             catch(Exception e){
                 System.out.println(e);
             }
       
    }
    
    public static void main(String[] args) {
        new Addemplyoee().setVisible(true);
    }
}
