
package hotelmanagementsystem;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LogIn extends JFrame implements ActionListener {
    JLabel l1,l2;
    JTextField t1;
    JPasswordField t2;
    JButton b1,b2;
    
    LogIn(){
    l1 = new JLabel("Username");
    l1.setBounds(40, 20, 100, 30);
    add(l1);
    
     l2 = new JLabel("Password");
    l2.setBounds(40, 70, 100, 30);
    add(l2);
    
     t1 = new JTextField();
    t1.setBounds(150, 20, 150, 30);
    add(t1);
    
setVisible(true);
      t2 = new JPasswordField();
    t2.setBounds(150, 70, 150, 30);
    add(t2);
    
      b1 = new JButton("LOGIN");
    b1.setBounds(40, 150, 120, 30);
    add(b1);
    
     b2 = new JButton("CANCEL");
    b2.setBounds(180, 150, 120, 30);
    add(b2);
    
    setLayout(null);
    
setBounds(400,300,400,250);
    }
    
      @Override
    public void actionPerformed(ActionEvent ae) {
       if(ae.getSource()==b1){
           new Dashboard().setVisible(true);
       this.setVisible(false);
       }
       else{
           new HotelManagementSystem().setVisible(true);
       this.setVisible(false);
       }
       
    }
    
     public static void main(String[] args) {
       new  LogIn() ;
    }

  
}


