
package hotelmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HotelManagementSystem extends JFrame implements ActionListener{
   
    HotelManagementSystem(){
       
    setBounds(170,20,1050,700);
       
      ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/f.jpg"));
      JLabel j1 = new JLabel(i1);
      j1.setBounds(0,0,1050,700);
      add(j1);
       
        JLabel j2 = new JLabel("Hotel Management System");
          j2.setBounds(60,30,1000,120);
          j2.setForeground(Color.MAGENTA);
       j2.setFont(new Font("forte",Font.BOLD,70));
      j1.add(j2);
      
       JButton b1 = new JButton("Next");
       b1.setBounds(850,590,100,50);
         b1.setFont(new Font("forte",Font.BOLD,28));
       b1.setForeground(Color.BLACK);
       b1.setBackground(Color.MAGENTA);
       b1.addActionListener(this);
               j1.add(b1);
                
               setLayout(null);
               setVisible(true);
       setDefaultCloseOperation(EXIT_ON_CLOSE);
   }
   
   @Override
       public void actionPerformed(ActionEvent ae) {
       new Dashboard().setVisible(true);
       this.setVisible(false);
    }
       
    public static void main(String[] args) {
       new  HotelManagementSystem() ;
    }
}