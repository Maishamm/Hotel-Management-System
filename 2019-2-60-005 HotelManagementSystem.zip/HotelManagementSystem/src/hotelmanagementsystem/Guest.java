
package hotelmanagementsystem;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.*;

public class Guest extends JFrame implements ActionListener {

JButton b1,b2;
JTable t1;
JLabel l1,l2,l3,l4,l5,l6;

Guest(){
    
        t1 = new JTable();
        t1.setBounds(0,30,900,280);
        add(t1);
               
        l1 = new JLabel("NID NO");
        l1.setBounds(10,3,50,25);
        add(l1);
        
         l2 = new JLabel("NAME");
        l2.setBounds(160,3,50,25);
        add(l2);
        
         l3 = new JLabel("GENDER");
        l3.setBounds(310,3,50,25);
        add(l3);
        
         l4 = new JLabel("ROOM NO");
        l4.setBounds(460,3,100,25);
        add(l4);
        
         l5 = new JLabel("CHECKED IN");
        l5.setBounds(610,3,130,25);
        add(l5);
        
         l6 = new JLabel("PAYMENT");
        l6.setBounds(760,3,100,25);
        add(l6);
        
          b1 = new JButton("Load");
          b1.setBounds(250,320,120,30);
          b1.addActionListener(this);
          add(b1);
             
          b2 = new JButton("Cancel");
          b2.setBounds(450,320,120,30);
          b2.addActionListener(this);
          add(b2);
          
         setLayout(null);
         setBounds(250,200,900,400);
         setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
       if(ae.getSource()== b1){
                   try{
                       conn c = new conn();
                       String str = "select * from guest" ;
                       ResultSet rs = c.s.executeQuery(str);
                       t1.setModel(DbUtils.resultSetToTableModel(rs));
                   }
                   catch(Exception e){
                       System.out.println(e);
                   }
       }
        else if(ae.getSource()==b2){
             this.setVisible(false);
                }
    }
    
    public static void main(String[] args) {
        new Guest().setVisible(true);
    }
}
