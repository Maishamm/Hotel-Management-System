
package hotelmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Addguest extends JFrame implements ActionListener {
    JLabel l1,l2,l3,l4,l5,l6;
    JTextField t1,t2,t3,t4;
    JRadioButton r1,r2;
    JButton b1;
    JComboBox c1;
    
Addguest(){
    
    l1 = new JLabel("NID No");
           l1.setBounds(60,30,120,30);
           l1.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(l1);
          
           t1 = new JTextField();
          t1.setBounds(200,30,150,30);
          add(t1);
          
           l2 = new JLabel("Name");
           l2.setBounds(60,80,120,30);
           l2.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(l2);
          
           t2 = new JTextField();
          t2.setBounds(200,80,150,30);
          add(t2);
          
            l3 = new JLabel("Gender");
           l3.setBounds(60,130,120,30);
           l3.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(l3);
          
           r1 = new JRadioButton("Male");
           r1.setBounds(200,130,70,30);
           r1.setFont(new Font("Tahoma",Font.PLAIN,14));
          add(r1);
          
             r2 = new JRadioButton("Female");
           r2.setBounds(280,130,70,30);
           r2.setFont(new Font("Tahoma",Font.PLAIN,14));
          add(r2);
                 
            l4 = new JLabel("Allocated Room");
           l4.setBounds(60,180,120,30);
           l4.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(l4);
          
          String str[] = {"101","102","103","104","105","201","202","203","204","205","206","301","302","303"};
          c1 = new JComboBox(str);
          c1.setBounds(200,180,150,30);
          add(c1);
          
            l5 = new JLabel("Checked In");
           l5.setBounds(60,230,120,30);
           l5.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(l5);
          
           t3 = new JTextField();
          t3.setBounds(200,230,150,30);
          add(t3);
      
           l6 = new JLabel("Payment");
           l6.setBounds(60,280,120,30);
           l6.setFont(new Font("Tahoma",Font.PLAIN,17));
          add(l6);
          
           t4 = new JTextField();
          t4.setBounds(200,280,150,30);
          add(t4);
          
          b1 = new JButton("Add");
          b1.setBounds(200,330,150,30);
          b1.addActionListener(this);
          add(b1);
          
         setLayout(null);
         setBounds(400,220,550,450);
         setVisible(true);
}    

    @Override
    public void actionPerformed(ActionEvent ae) {
       String NID_No = t1.getText();
         String Name = t2.getText();
           String Checked_In = t3.getText();
             String Payment = t4.getText();
             
             String Gender = null;
             if(r1.isSelected()){
                 Gender = "Male";
              }
             else if(r2.isSelected()){
                 Gender = "Female";
             }
             
             String Allocated_Room =(String)c1.getSelectedItem(); 
             conn c = new conn();
             
             String str = "insert into guest values('"+NID_No+"','"+Name+"','"+Gender+"','"+Allocated_Room+"','"+Checked_In+"','"+Payment+"')";
            //String str1 = "update room set available = 'Occupied' where room = '"+Allocated_Room+"'";
             try{
                c.s.executeUpdate(str);
                 //c.s.executeUpdate(str1);
               JOptionPane.showMessageDialog(null,"New Customer Added");
                this.setVisible(false);
             }
             catch(Exception e){
                 System.out.println(e);
             }
       
}
    
    public static void main(String[] args) {
        new Addguest().setVisible(true);
    }

}