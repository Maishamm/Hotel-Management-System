
package hotelmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Addroom extends JFrame implements ActionListener {

    JLabel l1,l2,l3,l4,l5;
    JTextField t1,t2,t3,t4;
    JRadioButton r1,r2;
    JButton b1,b2;
    JComboBox c1;

    Addroom(){
        
        l1 = new JLabel("Add Room");
        l1.setBounds(200,20,100,20);
        l1.setFont(new Font("Tahoma", Font.PLAIN,16));
        add(l1);
        
         l2 = new JLabel("Room Number");
        l2.setBounds(60,80,120,30);
        l2.setFont(new Font("Tahoma", Font.PLAIN,16));
        add(l2);
        
        t1 = new JTextField();
        t1.setBounds(200,80,150,30);
        add(t1);
        
         l3 = new JLabel("Available");
        l3.setBounds(60,130,120,30);
        l3.setFont(new Font("Tahoma", Font.PLAIN,16));
        add(l3);
        
        c1 = new JComboBox(new String[]{"Available","Occupied"});
        c1.setBounds(200,130,150,30);
        add(c1);
        
         l4 = new JLabel("Price");
        l4.setBounds(60,180,120,30);
        l4.setFont(new Font("Tahoma", Font.PLAIN,16));
        add(l4);
        
        t2 = new JTextField();
        t2.setBounds(200,180,150,30);
        add(t2);
        
        b1 = new JButton("Add Room");
        b1.setBounds(60,300,130,30);
        add(b1);
        b1.addActionListener(this);
        
        b2 = new JButton("Cancel");
        b2.setBounds(220,300,130,30);
        add(b2);
          b2.addActionListener(this);
         
          setLayout(null);
         setBounds(430,220,450,450);
         setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
               if(ae.getSource()==b1){
                   String room = t1.getText();
                   String available = (String)c1.getSelectedItem();
                   String price = t2.getText();
                    conn c = new conn();
                    try{
                     String str = "insert into room values('"+room+"','"+available+"','"+price+"')";
                     c.s.executeUpdate(str);
                     JOptionPane.showMessageDialog(null,"New Room Added");
                this.setVisible(false);
                    }catch(Exception e){
                        System.out.println(e);
                    }
       }
               else if(ae.getSource()==b2){
                   this.setVisible(false);
             
       }
    }
    public static void main(String[] args) {
        new Addroom().setVisible(true);
    }
    
}
