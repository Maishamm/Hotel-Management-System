
package hotelmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Dashboard extends JFrame implements ActionListener {

    JMenuBar mb;
    JMenu m1,m2,m3;
    JMenuItem l1,l2,l3,l4;
    
Dashboard(){
    
    mb = new JMenuBar();
    mb.setBackground(Color.cyan);
    add(mb);
    
    m1 = new JMenu("Hotel Management");
           m1.setFont(new Font("forte",Font.BOLD,30));
    mb.add(m1);
    
      m2 = new JMenu(" Admin ");
             m2.setFont(new Font("forte",Font.BOLD,30));
    mb.add(m2);
       
     l1 = new JMenuItem("Reception");
      l1.setFont(new Font("forte",Font.BOLD,30));
     l1.addActionListener(this);
     m1.add(l1);
     
       l2 = new JMenuItem("Add Employee");
        l2.setFont(new Font("forte",Font.BOLD,30)); 
       l2.addActionListener(this);
     m2.add(l2);
     
       l3 = new JMenuItem("Add Room");
        l3.setFont(new Font("forte",Font.BOLD,30)); 
       l3.addActionListener(this);
     m2.add(l3);
     
       //l4 = new JMenuItem("Add Drivers");
     //m2.add(l4);
     
     mb.setBounds(0,0,1050,40);
     
     ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotelmanagementsystem/icons/2.jpg"));
     JLabel j1 = new JLabel(i1);
     j1.setBounds(0,0,1050,700);
     add(j1);
     
     JLabel j2 = new JLabel("Welcome to Grand Hotel");
           j2.setBounds(210,40,900,120);
          j2.setForeground(Color.BLACK);
       j2.setFont(new Font("forte",Font.BOLD,60));
      j1.add(j2);
      
         setLayout(null);
         setBounds(170,20,1050,700);
         setVisible(true);
}  

 @Override
    public void actionPerformed(ActionEvent ae) {
       if(ae.getActionCommand().equals("Reception")){
                      new Reception().setVisible(true);
       }
       else if(ae.getActionCommand().equals("Add Employee")){
           new Addemplyoee().setVisible(true);
       }
       else if(ae.getActionCommand().equals("Add Room")){
           new Addroom().setVisible(true);
    }
}
    
    public static void main(String[] args) {
        new Dashboard().setVisible(true);
    }
}
