
package hotelmanagementsystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Reception extends JFrame implements ActionListener {

    JButton b1,b2,b3,b4,b5,b6;
      int c = 0;
    
    Reception(){

        b1 = new JButton("Customer Form");
         b1.setFont(new Font("forte",Font.BOLD,16));
b1.setBounds(130,40,150,30);
add(b1);
b1.addActionListener(this);

    b2 = new JButton("Employee Info");
     b2.setFont(new Font("forte",Font.BOLD,15));
b2.setBounds(130,80,150,30);
add(b2);
b2.addActionListener(this);

    b3 = new JButton("Room Info");
     b3.setFont(new Font("forte",Font.BOLD,16));
b3.setBounds(130,120,150,30);
add(b3);
b3.addActionListener(this);

    b4 = new JButton("Customer Info");
b4.setBounds(130,160,150,30);
 b4.setFont(new Font("forte",Font.BOLD,16));
add(b4);
b4.addActionListener(this);

    b5 = new JButton("Check Out");
 b5.setFont(new Font("forte",Font.BOLD,16));
    b5.setBounds(130,200,150,30);
add(b5);
b5.addActionListener(this);

    b6 = new JButton("Logout");
 b6.setFont(new Font("forte",Font.BOLD,16));
    b6.setBounds(130,240,150,30);
add(b6);
b6.addActionListener(this);

  setLayout(null);
         setBounds(440,250,450,370);
         setVisible(true);
    }
    
@Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==b1){
        new Addguest().setVisible(true);
                   this.setVisible(false);    
    }
        else if(ae.getSource()==b2){
             new EmployeeInfo().setVisible(true);
                   this.setVisible(false);
        }
      else if(ae.getSource()==b3){
          new Room().setVisible(true);
                   this.setVisible(false);
        }
      else if(ae.getSource()==b4){
          new Guest().setVisible(true);
                   this.setVisible(false);
        }
      else if(ae.getSource()==b5){
                   this.setVisible(false);
        }
      else if(ae.getSource()== b6){
          new HotelManagementSystem().setVisible(true);
          this.setVisible(false);
    
    }
}
    public static void main(String[] args) {
        new Reception().setVisible(true);
    }
}
