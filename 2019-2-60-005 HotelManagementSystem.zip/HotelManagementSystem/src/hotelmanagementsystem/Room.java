
package hotelmanagementsystem;

import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.*;

public class Room  extends JFrame implements ActionListener  {

    JButton b1,b2;
JTable t1;
JLabel l1,l2,l3,l4,l5,l6;
    
Room (){
    
        t1 = new JTable();
        t1.setBounds(0,30,600,280);
        add(t1);
                
        l1 = new JLabel("ROOM NO");
        l1.setBounds(10,3,70,25);
        add(l1);
        
          l2 = new JLabel("STATUS");
        l2.setBounds(210,3,70,25);
        add(l2);
        
          l3 = new JLabel("PRICE");
        l3.setBounds(410,3,70,25);
        add(l3);
        
          b1 = new JButton("Load");
          b1.setBounds(130,320,120,30);
          b1.addActionListener(this);
          add(b1);
             
          b2 = new JButton("Cancel");
          b2.setBounds(320,320,120,30);
          b2.addActionListener(this);
          add(b2);
          
         setLayout(null);
         setBounds(370,220,600,400);
         setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
       if(ae.getSource()== b1){
                   try{
                       conn c = new conn();
                       String str = "select * from room" ;
                       ResultSet rs = c.s.executeQuery(str);
                       t1.setModel(DbUtils.resultSetToTableModel(rs));
                   }
                   catch(Exception e){
                       System.out.println(e);
                   }
       }
        else if(ae.getSource()==b2){
             this.setVisible(false);
                }
    }
    
    public static void main(String[] args) {
        new Room().setVisible(true);
    }
}
